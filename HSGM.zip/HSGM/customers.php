<?php
  include_once('config.php');
  $query = "SELECT * FROM customers";
  $result = mysqli_query($mysqli, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Lou Geh</title>
</head>
<body>
  <nav>
  <h1>THE LOU GEH SUPERMARKET</h1>
      <li><a href="items.php">Items</a></li>
      <li><a href="customers.php">Customer</a></li>
      <li><a href="suppliers.php">Supplier</a></li>
  
    </ul>
  </nav>
  <div class="main">
  <div class="mainContent">
    <div class="forTable">
      <table>
        <thead>
          <tr>
            <td>Customer Id</td>
            <td>Customer Name</td>
            <td>Customer Contact Number</td>
            <td>Customer Address</td>
          </tr>
        </thead>
<?php 
while($res = mysqli_fetch_assoc($result)) {
  echo "<tr>";
    echo "<td>".$res['customer_id']."</td>";
    echo "<td>".$res['customer_name']."</td>";
    echo "<td>".$res['customer_contact_number']."</td>";
    echo "<td>".$res['customer_address']."</td>";

}
?>
      </table>
    </div>  
    <div class="forAdding">
      <h3>Add new item</h3>
      <form action="add_customer.php" method="POST">

        <label for="Customer Id">Customer Id</label>
        <input type="text" value="" name="customer_id">

        <label for="Customer Name">Customer Name</label>
        <input type="text" value="" name="customer_name">

        <label for="Customer Contact Number">Customer Contact Number</label>
        <input type="text" value="" name="customer_contact_number">

        <label for="Customer Address">Customer Address</label>
        <input type="text" value="" name="customer_address">

        <button type="submit" name="submit">Submit</button>
      </form>
    </div>  
  </div>
  </div>
</body>
</html>