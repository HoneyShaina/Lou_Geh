<?php

$databaseHost = 'localhost';
$databaseUsername = 'root';
$databasePassword = '';
$databaseName = 'hshainag';

$mysqli = mysqli_connect(
  "$databaseHost",
  "$databaseUsername",
  "$databasePassword",
  "$databaseName"
);