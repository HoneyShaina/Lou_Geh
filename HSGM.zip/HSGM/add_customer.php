<?php

include_once 'config.php';

$customer_id=filter_input(INPUT_POST, 'customer_id');
$customer_name=filter_input(INPUT_POST, 'customer_name');
$customer_contact_number=filter_input(INPUT_POST, 'customer_contact_number');
$customer_address=filter_input(INPUT_POST, 'customer_address');

if(isset($_POST['submit'])){
    if(mysqli_connect_error()){
        die('Connection Error ('.mysqli_connect_error().')'
        .mysqli_connect_error());
    }else{
        $sql = "INSERT INTO customers (customer_id, customer_name, customer_contact_number, customer_address)
        VALUES('$customer_id', '$customer_name', '$customer_contact_number', '$customer_address')";
    
    if ($mysqli->query($sql) === TRUE) {
        header('Location: customers.php');
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
    }
} 

?>