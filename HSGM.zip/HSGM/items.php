<?php
  include_once('config.php');
  $query = "SELECT * FROM items";
  $result = mysqli_query($mysqli, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/style.css?v=<?php echo time(); ?>">
  <title>Lou Geh</title>
</head>
<body>
  <nav>
   <h1>THE LOU GEH SUPERMARKET</h1>
      <li><a href="items.php">Items</a></li>
      <li><a href="customers.php">Customer</a></li>
      <li><a href="suppliers.php">Supplier</a></li>
   
    </ul>
  </nav>
  <div class="main">
  <div class="mainContent">
    <div class="forTable">
      <table>
        <thead>
          <tr>
            <td>Barcode</td>
            <td>Product Description</td>
            <td>Quantity</td>
            <td>Price</td>
          </tr>
        </thead>
<?php 
while($res = mysqli_fetch_assoc($result)) {
  echo "<tr>";
    echo "<td>".$res['barcode']."</td>";
    echo "<td>".$res['pdescription']."</td>";
    echo "<td>".$res['quantity']."</td>";
    echo "<td>".$res['price']."</td>";
}
?>
      </table>
    </div>  
    <div class="forAdding">
      <h3>Add new item</h3>
      <form action="add_items.php" method="POST">
        <label for="barcode">Barcode</label>
        <input type="text" value="" name="barcode">


        <label for="Product Description">Product Description</label>
        <input type="text" value="" name="pdescription">

        <label for="Quantity">Quantity</label>
        <input type="text" value="" name="quantity">
        
        <label for="Price">Price</label>
        <input type="text" value="" name="price">
        <button type="submit" name="submit">Submit</button>
      </form>
    </div>  
  </div>
  </div>
</body>
</html>