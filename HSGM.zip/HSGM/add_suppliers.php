<?php

include_once 'config.php';

$company_id=filter_input(INPUT_POST, 'company_id');
$company_name=filter_input(INPUT_POST, 'company_name');
$company_contact_number=filter_input(INPUT_POST, 'company_contact_number');
$company_address=filter_input(INPUT_POST, 'company_address');

if(isset($_POST['submit'])){
    if(mysqli_connect_error()){
        die('Connection Error ('.mysqli_connect_error().')'
        .mysqli_connect_error());
    }else{
        $sql = "INSERT INTO suppliers (company_id, company_name, company_contact_number, company_address)
        VALUES('$company_id', '$company_name', '$company_contact_number', '$company_address')";
    
    if ($mysqli->query($sql) === TRUE) {
        header('Location: suppliers.php');
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
    }
} 

?>