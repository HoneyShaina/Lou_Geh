<?php

include_once 'config.php';

$barcode=filter_input(INPUT_POST, 'barcode');
$pdescription=filter_input(INPUT_POST, 'pdescription');
$quantity=filter_input(INPUT_POST, 'quantity');
$price=filter_input(INPUT_POST, 'price');

if(isset($_POST['submit'])){
    if(mysqli_connect_error()){
        die('Connection Error ('.mysqli_connect_error().')'
        .mysqli_connect_error());
    }else{
        $sql = "INSERT INTO items (barcode, pdescription, quantity, price)
        VALUES ('$barcode','$pdescription', '$quantity',
        '$price')";

    if ($mysqli->query($sql) === TRUE) {
        header('Location: items.php');
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
    }
} 

?>