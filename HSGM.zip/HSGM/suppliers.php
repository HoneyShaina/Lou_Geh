<?php
  include_once('config.php');
  $query = "SELECT * FROM suppliers";
  $result = mysqli_query($mysqli, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Lou Geh</title>
</head>
<body>
  <nav>
    <h1>THE LOU GEH SUPERMARKET</h1>
      <li><a href="items.php">Items</a></li>
      <li><a href="customers.php">Customer</a></li>
      <li><a href="suppliers.php">Supplier</a></li>

    </ul>
  </nav>
  <div class="main">
  <div class="mainContent">
    <div class="forTable">
      <table>
        <thead>
          <tr>
            <td>Company Id</td>
            <td>Company Name</td>
            <td>Company Contact Number</td>
            <td>Company Address</td>
          </tr>
        </thead>
<?php 
while($res = mysqli_fetch_assoc($result)) {
  echo "<tr>";
    echo "<td>".$res['company_id']."</td>";
    echo "<td>".$res['company_name']."</td>";
    echo "<td>".$res['company_contact_number']."</td>";
    echo "<td>".$res['company_address']."</td>";

}
?>
      </table>
    </div>  
    <div class="forAdding">
      <h3>Add new item</h3>
      <form action="add_suppliers.php" method="POST">

        <label for="Company Id">Company Id</label>
        <input type="text" value="" name="company_id">

        <label for="Company Name">Company Name</label>
        <input type="text" value="" name="company_name">

        <label for="Company Contact Number">Company Contact Number</label>
        <input type="text" value="" name="company_contact_number">

        <label for="Company Address">Company Address</label>
        <input type="text" value="" name="company_address">

        <button type="submit" name="submit">Submit</button>
      </form>
    </div>  
  </div>
  </div>
</body>
</html>